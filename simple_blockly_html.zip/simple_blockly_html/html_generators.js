"use strict";


var HtmlGenerator = new Blockly.Generator('HTML');

HtmlGenerator.init = function(workspace) {};
HtmlGenerator.finish = function(code) {return code;};

HtmlGenerator.scrub_ = function(block, code) {
  var nextBlock = block.nextConnection && block.nextConnection.targetBlock();
  var nextCode = HtmlGenerator.blockToCode(nextBlock);
  return code + nextCode;
};


function removeIndentAndTrailingNewline() {
   
}

/***********************************************************/

HtmlGenerator['Function_1'] = function(block) {
  var value = block.getFieldValue('VALUE');
  var value2 = block.getFieldValue('VALUE2');
  var value3 = block.getFieldValue('VALUE3');
  var code = value + value2 + value3 + '\n';
  return code;
};

HtmlGenerator['Function_2'] = function(block) {
  var value = block.getFieldValue('VALUE');
  var value2 = block.getFieldValue('VALUE2');
  var value3 = block.getFieldValue('VALUE3');
  var code = value + value2 + value3 + '\n';
  return code;
};

/***********************************************************/

