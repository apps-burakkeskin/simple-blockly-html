Msg = {
  categories: {
    "baseframe": "Menü 1",
  },
  blocks: {  }
}




