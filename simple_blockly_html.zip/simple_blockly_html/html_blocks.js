"use strict";


var htmlBlocks =
[
  /***********************************************************/
  {
    "type": "Function_1",
    "message0": "FUNCTION_1 %1 | %2 | %3",
    "args0": [
    {
      "type": "field_input",
      "name": "VALUE",
      "text": "value",
    },
    {
      "type": "field_input",
      "name": "VALUE2",
      "text": "value"
    },
    {
      "type": "field_angle",
      "name": "VALUE3",
      "angle": 90,
    }
    ],
    "previousStatement": null,
    "nextStatement": ["Function_2"],
    // "output": ["Function_2"],
    "inputsInline": true,
    "colour": '#da231e',
    "tooltip": "Üzerine gelince çıkan açıklama",
    "helpUrl": "http://www.w3schools.com/tags/tag_html.asp",
  },
  {
    "type": "Function_2",
    "message0": "FUNCTION_2 %1 | %2 | %3",
    "args0": [
    {
      "type": "field_input",
      "name": "VALUE",
      "text": "value",
    },
    {
      "type": "field_input",
      "name": "VALUE2",
      "text": "value"
    },
    {
      "type": "field_angle",
      "name": "VALUE3",
      "angle": 90,
    }
    ],
    "previousStatement": null,
    "nextStatement": ["Function_1"],
    // "output": ["Function_1"],
    "inputsInline": true,
    "colour": '#da231e',
    "tooltip": "Üzerine gelince çıkan açıklama",
    "helpUrl": "http://www.w3schools.com/tags/tag_html.asp",
  },
  /***********************************************************/
  ];

if (Msg && Msg.blocks) {
  // Update jsons with translations
  for (var iBlock in htmlBlocks) {
    var json = htmlBlocks[iBlock];
    var trs = Msg.blocks[json.type];
    for (var iTr in trs) {
      if (typeof(trs[iTr]) == "string") {
        json[iTr] = trs[iTr];
      } else if (typeof(trs[iTr]) == "object") {
        // Mainly for args0 property
        // Follow two levels, then just replace
        for (var iTrObj in trs[iTr]) {
          if (typeof(trs[iTr][iTrObj]) == "object") {
            for (var index in trs[iTr][iTrObj]) {
              json[iTr][iTrObj][index] = trs[iTr][iTrObj][index];
            }
          }
          else {
            console.error("Don't know how to translate that: Msg.blocks." + iTr + "." + iTrObj)
          }
        }
      } else {
        console.error("Don't know how to translate that: Msg.blocks." + iTr)
      }
    }
  }
}

for (var iBlock in htmlBlocks) {
  function makeBlock(json) {
    Blockly.Blocks[json.type] = {
      init: function() {
        this.jsonInit(json);
      }
    }
  }
  makeBlock(htmlBlocks[iBlock]);
}


